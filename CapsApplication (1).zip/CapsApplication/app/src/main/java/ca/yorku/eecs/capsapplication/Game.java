package ca.yorku.eecs.capsapplication;

import java.util.List;
import java.util.Map;

import ca.roumani.i2c.Country;
import ca.roumani.i2c.CountryDB;

public class Game
{
    private CountryDB db;

    public Game()
    {
        this.db = new CountryDB();
    }


    public String qa()
    {
        List<String> capitals = this.db.getCapitals();
        int n = capitals.size();
        int index = (int)(n * Math.random());
        String c = capitals.get(index);
        Map<String, Country> data = this.db.getData();
        Country ref = data.get(c);
        String question;

        if (Math.random() < 0.5)
        // What is the capital of [country]?
        {
            question = "What is the capital of " + ref.getName() + "?\n" + c;
        }
        else
        // [capital] is the capital of?
        {
            question = c + " is the capital of?\n" + ref.getName();
        }
        System.out.println(question);
        return question;


    }



    public static void main(String[] args)
    {
        System.out.println("Test start!");
        Game game = new Game();
        for (int i = 0; i < 5; i++)
        {
            System.out.println(game.qa());
        }


    }
}
