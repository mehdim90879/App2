package ca.yorku.eecs.capsapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.List;
import java.util.Map;

import ca.roumani.i2c.Country;
import ca.roumani.i2c.CountryDB;

public class MainActivity extends AppCompatActivity
{
    private Game game;
    private String question;
    private String answer;
    private int score;
    private int qNum;
    private String log;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        this.game = new Game();
        this.score = 0;
        this.qNum = 1;
        this.log = "";
        this.ask();
    }

    private void ask()
    {
        String questionAnswer = this.game.qa();
        String[] splitQuestionAnswer = questionAnswer.split("\n");
        this.question = splitQuestionAnswer[0];
        this.answer = splitQuestionAnswer[1];
        ((TextView)findViewById(R.id.question)).setText(this.question);
    }

    public void onDone(View v)
    {
        if (this.qNum == 10)
        {
            this.finish();
        }
        else
        {
            String answer = ((EditText)findViewById(R.id.answer)).getText().toString().toUpperCase();
            ((EditText)findViewById(R.id.answer)).setText("");
            String correctAnswer = this.answer.toUpperCase();
            if (answer.equals(correctAnswer))
            {
                this.score++;
            }
            ((TextView)findViewById(R.id.score)).setText(String.format("SCORE = %d", this.score));
            String currentLog = String.format("Q# %d: %s\nYour answer: %s\nCorrect answer: %s\n\n", this.qNum, this.question, answer, this.answer);
            System.out.println(currentLog);
            this.log = currentLog + this.log;
            ((TextView)findViewById(R.id.log)).setText(this.log);
            this.qNum++;
            if (this.qNum == 10)
            {
                ((TextView)findViewById(R.id.qNum)).setText("Game Over");
                ((Button)findViewById(R.id.done)).setEnabled(false);
            }
            else
            {
                ((TextView)findViewById(R.id.qNum)).setText(String.format("Q# %d", this.qNum));
                this.ask();
            }
        }
    }

}
